

class Calculadora {

    static soma(a, b) {
        return a + b;
    }
    static divisao = (a, b) => {
        return a / b;
    }
    static mult(a, b) {
        return a * b;
    }
    static sub(a, b) {
        return a - b;
    }
}

export default Calculadora
// module.exports = Calculadora;