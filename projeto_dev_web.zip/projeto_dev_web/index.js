


// // const calc = require('./calc')
// // const Calculadora = require('./calculadora')
// import calculadora from "./calculadora.js";

// let a = 5;
// var b = 10;
// const c = 1;


// function delay(ms) {
//     return new Promise(r => setTimeout(r, ms));
// }

// async function main() {

//     while (true) {
//         try {

//             const retSomaCalc = calculadora.soma(a, b);

//             console.log(retSomaCalc)


//             console.log(calculadora.mult(a, b))
//         }catch (err) {
//             // kafka(err)
//         } finally{
//             await delay(10000)
//         }
//     }

// }



// main()




// // print(a, b, somaa)